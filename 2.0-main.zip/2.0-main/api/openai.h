#ifndef OPENAI_H
#define OPENAI_H

// Función para enviar un prompt a la API de OpenAI
char* send_prompt(const char* prompt, const char* role_file);

#endif /* OPENAI_H */
#ifndef COMMON_H
#define COMMON_H

// Incluir todas las cabeceras de componentes comunes
#include "utils.h"
#include "context.h"

// Inicialización general de componentes comunes
void common_init();

#endif /* COMMON_H */
#ifndef CONTEXT_H
#define CONTEXT_H
void append_to_context(const char* cmd, const char* output);
void load_context();
#endif
